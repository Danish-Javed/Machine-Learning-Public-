'''
Name: Danish Javed (L1F20PHDC0001)
'''
import string 
import nltk
nltk.download('punkt')
from nltk.tokenize import sent_tokenize
from nltk import word_tokenize
from nltk.corpus import stopwords, wordnet
from nltk.stem import WordNetLemmatizer
from nltk.stem import PorterStemmer
import pandas as pd
import matplotlib.pyplot as plt
import csv
import contractions
from collections import Counter
from autocorrect import Speller
from wordcloud import WordCloud, STOPWORDS
pd.options.mode.chained_assignment = None

#Read txt file
with open('corporaForSpellCorrection.txt', 'r') as file:
    file_contents = file.read()
#count number of total words and sentences
    print('\nTotal words:   ', len(file_contents.split()))
    print('Sentence count using fullstop as separater:    ', file_contents.count('.'))

#count total sentences using nltk
number_of_sentences = sent_tokenize(file_contents)
print('Sentence count using nltk=', len(number_of_sentences))
#Remove Line spaces from the data
new_contents= file_contents.replace('\n\n', '\n')
new_contents= new_contents.replace('\n\n', '\n') 
print('Paragraph count:    ', new_contents.count('\n\n'))
corpus = pd.read_csv("corporaForSpellCorrection.csv", low_memory=False)
#remove all the null rows from data
corpus['null_row'] = corpus[corpus['A'].notnull()]
length = len(corpus['null_row'])
print('Length of Corpus = ',length)
#remove Digits
corpus['noDigit'] = corpus['null_row'].apply(lambda x:''.join([i for i in x if not i.isdigit()]))

#remove URLs
corpus['no_URL'] = corpus['noDigit'].replace(r'http\S+', '', regex=True).replace(r'www\S+', '', regex=True)


#remove underscores with words in between, because it was not detected by punctuation
corpus['underscore'] = corpus['no_URL'].replace('_*_', ' ', regex=True)
#remove special characters
corpus['no_special'] = corpus['underscore'].replace(r'\W+', ' ', regex=True)
#remove words with 2 characters or less
corpus['twoChar'] = corpus['no_special'].apply(str).str.replace(r'\b(\w{1,2})\b', '')

#SPELL CHECKING through AUTOCORRECT library
spell=Speller(lang="en")
corpus['spell_corrected'] = corpus['twoChar'].apply(lambda doc: ' '.join([spell(w).lower() for w in doc.split()]))

#remove common words
common_words = {s.strip('\n'):0 for s in open("Common english words.txt","r", encoding='utf-8').readlines()}
corpus['remove_words'] = corpus['spell_corrected'].apply(lambda doc: ' '.join([word for word in doc.split() if word not in (common_words)]))

#tokenize the documents
corpus['tokenized'] = corpus['remove_words'].apply(word_tokenize)
#expand contractions
corpus['no_contractions'] = corpus['tokenized'].apply(lambda x: [contractions.fix(word) for word in x])
#lower case all the words
corpus['lower'] = corpus['no_contractions'].apply(lambda x: [word.lower() for word in x])
#remove punctuations
punc = string.punctuation
corpus['no_punc'] = corpus['lower'].apply(lambda x: [word for word in x if word not in punc])



#remove stops words
stop_words = set(stopwords.words('english'))
corpus['stopwords_removed'] = corpus['no_punc'].apply(lambda x: [word for word in x if word not in stop_words])

#Apply pos tagging for lemmatization
corpus['pos_tags'] = corpus['stopwords_removed'].apply(nltk.tag.pos_tag)
def get_wordnet_pos(tag):
    if tag.startswith('J'):
        return wordnet.ADJ
    elif tag.startswith('V'):
        return wordnet.VERB
    elif tag.startswith('N'):
        return wordnet.NOUN
    elif tag.startswith('R'):
        return wordnet.ADV
    else:
        return wordnet.NOUN
corpus['wordnet_pos'] = corpus['pos_tags'].apply(lambda x: [(word, get_wordnet_pos(pos_tag)) for (word, pos_tag) in x])
#Apply lemmatization through WorldNetLematizer
wnl = WordNetLemmatizer()
corpus['lemmatized'] = corpus['wordnet_pos'].apply(lambda x: [wnl.lemmatize(word, tag) for word, tag in x])
corpus['joinlemmatized'] = [' '.join(x) for x in corpus['lemmatized']]

#Applying stemming through Porter stemmer
ps = PorterStemmer()
corpus['stemmed'] = corpus['joinlemmatized'].apply(lambda doc: ' '.join([ps.stem(w) for w in doc.split()]))
corpus['preprocessed']= corpus['stemmed']
corpus['preprocessed'].to_csv('PreprocessedData.csv', index=False)

# to find the number of total words, stop words, common words and punctuation count in the data
total_word_count = {}
stops_count = {}
common_count = {}
punc_count = {}
for doc in corpus['null_row']:
    tokens = doc.split()
    for token in tokens:
        token = token.strip().lower()
#total word count before preprocess
        if token not in total_word_count:
            total_word_count[token] = 0
        total_word_count[token] += 1
#total stop word count
        if token in stop_words:
            if token not in stops_count:
                stops_count[token] = 0
            stops_count[token] += 1
# most common 1000 word count         
        if token in common_words:
            if token not in stop_words:
                if token not in common_count:
                    common_count[token] = 0
                common_count[token] += 1
#punctuation count        
        if token in punc:
            if token not in punc_count:
                punc_count[token] = 0
            punc_count[token] += 1
with open("Total_word_count before preprocess.csv", 'w' , newline='',  encoding='utf-8') as csvfile:
    writer = csv.writer(csvfile)
    writer.writerows(total_word_count.items())
with open("stop word count.csv", 'w' , newline='',  encoding='utf-8') as csvfile:
    writer = csv.writer(csvfile)
    writer.writerows(stops_count.items())
with open("common_word_count.csv", 'w' , newline='',  encoding='utf-8') as csvfile:
    writer = csv.writer(csvfile)
    writer.writerows(common_count.items())   
with open("Punctuation_count.csv", 'w' , newline='',  encoding='utf-8') as csvfile:
    writer = csv.writer(csvfile)
    writer.writerows(punc_count.items())

#Unique vocabulary count after preprocessing data
unique_vocab_count = {}
for doc in corpus['preprocessed']:
    tokens = doc.split()
    for token in tokens:
        if token not in  common_words:
            if token not in unique_vocab_count:
                unique_vocab_count[token] = 0
            unique_vocab_count[token] += 1
with open("Unique vocab count.csv", 'w' , newline='',  encoding='utf-8') as csvfile:
    writer = csv.writer(csvfile)
    writer.writerows(unique_vocab_count.items())

#Most popular Words from data in the form of graph
def wordBarGraph(data,column,title):
    topic_words = [ z.lower() for y in
                       [ x.split() for x in data[column] if isinstance(x, str)]
                       for z in y]
    word_count_dict = dict(Counter(topic_words))
    popular_words = sorted(word_count_dict, key = word_count_dict.get, reverse = True)
    popular_words_nonstop = [w for w in popular_words if w not in common_words]
    plt.barh(range(50), [word_count_dict[w] for w in reversed(popular_words_nonstop[0:50])])
    plt.yticks([x + 0.5 for x in range(50)], reversed(popular_words_nonstop[0:50]))
    plt.title(title)
    plt.show()

plt.figure(figsize=(10,10))
wordBarGraph(corpus,'preprocessed',"Popular Words after preprocessing")

#Most popular Words from the data in the form of word cloud
def wordCloud(data,column,numWords):
    topic_words = [ z.lower() for y in
                       [ x.split() for x in data[column] if isinstance(x, str)]
                       for z in y]
    word_count_dict = dict(Counter(topic_words))
    popular_words = sorted(word_count_dict, key = word_count_dict.get, reverse = True)
    popular_words_nonstop = [w for w in popular_words if w not in common_words]
    word_string=str(popular_words_nonstop)
    wordcloud = WordCloud(background_color='white',max_words=numWords, width=1000,height=1000,).generate(word_string)
    plt.clf()
    plt.imshow(wordcloud)
    plt.axis('off')
    plt.show()    
plt.figure(figsize=(10,10))
wordCloud(corpus,'preprocessed',100)